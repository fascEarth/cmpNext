import styles from './Footer.module.css';
function SurfaceFooter() {
    return (
      <footer className={styles.footer}>
        <p>&copy; 2023 My Blog</p>
      </footer>
    );
  }
  
  export default SurfaceFooter;
  