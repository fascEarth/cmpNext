import styles from './index.module.css';
import SignupLayout from '../../components/layouts/signup/Layout';
import { useState } from 'react';







function Signup() {


  

  return (
  <>
  <SignupLayout>
  <div className={styles.container}>
      <h1>Welcome to the Signup</h1>
      <p>Here is where you can manage your account and view your orders.</p>
      <div className={styles.orderList}>
        <h2>Your Orders</h2>
        <ul>
          <li>Order 1</li>
          <li>Order 2</li>
          <li>Order 3</li>
        </ul>
      </div>
    </div>
    </SignupLayout>
  </>
  );
};


export default Signup;
