import FallbackSpinner from "../components/tools/spinner";

const Home = () => {
  return <FallbackSpinner />
}

export default Home
